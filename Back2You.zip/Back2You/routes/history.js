const router = require('express').Router();
const History = require('../models/History');
const { requireAuth } = require('../middleware/auth');

router.use(requireAuth);

// Outcomes a person may see about THEIR report / THEIR claim, even though management did them
const OUTCOMES = ['REPORT_VERIFIED', 'REPORT_REJECTED', 'CLAIM_REJECTED', 'ITEM_HANDED_OVER', 'HANDOVER_REVERSED'];

function shapeFor(e, me) {
  const out = {
    id: String(e._id), action: e.action, itemName: e.itemName, itemType: e.itemType,
    timestamp: e.timestamp, actor: { name: e.actor && e.actor.name, idNo: e.actor && e.actor.idNo, role: e.actor && e.actor.role },
    details: e.details || {}
  };
  if (me.role === 'management') return out;

  const mine = String(e.actor && e.actor.user) === String(me._id);
  if (!mine) {
    out.actor = { role: e.actor && e.actor.role };           // hide who inside management did it
    out.details = e.action === 'REPORT_REJECTED' ? { note: (e.details || {}).note } : {};
  }
  return out;
}

router.get('/', async (req, res) => {
  const me = req.user;
  const filter = me.role === 'management' ? {} : {
    $or: [
      { 'actor.user': me._id },
      { action: { $in: OUTCOMES }, $or: [{ ownerId: me._id }, { targetUser: me._id }] }
    ]
  };
  const rows = await History.find(filter).sort({ timestamp: -1 }).limit(300).lean();
  res.json(rows.map(e => shapeFor(e, me)));
});

module.exports = router;
