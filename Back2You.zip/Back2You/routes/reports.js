const router = require('express').Router();
const mongoose = require('mongoose');
const rateLimit = require('express-rate-limit');
const Report = require('../models/Report');
const Claim = require('../models/Claim');
const { requireAuth } = require('../middleware/auth');
const { clean, isValidDate, notInFuture } = require('../utils/validate');
const parsePhoto = require('../utils/photo');
const shape = require('../utils/shape');
const { log } = require('../utils/history');

router.use(requireAuth);

const bad = (res, message) => res.status(400).json({ message });
const createLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false,
  message: { message: 'Too many reports. Please try again later.' } });

// Board: only items management has verified. No reporter details.
router.get('/public', async (req, res) => {
  const reports = await Report.find({ status: { $in: ['verified', 'returned'] } })
    .sort({ date: -1, createdAt: -1 }).limit(500).lean();
  const claims = await Claim.find({ 'by.user': req.user._id }).select('report status').lean();
  const claimMap = new Map(claims.map(c => [String(c.report), c.status]));
  res.json(reports.map(r => shape.publicReport(r, req.user, claimMap)));
});

// The signed-in person's own submissions, including pending / rejected ones
router.get('/mine', async (req, res) => {
  const reports = await Report.find({ 'reporter.user': req.user._id }).sort({ createdAt: -1 }).limit(200).lean();
  res.json(reports.map(shape.mineReport));
});

// Submit a lost / found report → goes to management for verification
router.post('/', createLimiter, async (req, res) => {
  const b = req.body || {};
  if (!['Lost', 'Found'].includes(b.type)) return bad(res, 'Choose Lost or Found.');
  if (!Report.CATEGORIES.includes(b.category)) return bad(res, 'Choose a valid category.');

  const name = clean(b.name, 70), description = clean(b.description, 350), location = clean(b.location, 100);
  const date = String(b.date || '');
  if (!name || !description || !location) return bad(res, 'Please complete all required fields.');
  if (!isValidDate(date) || !notInFuture(date)) return bad(res, 'Enter a valid date (not in the future).');

  let photo;
  if (b.photo) {
    photo = parsePhoto(b.photo);
    if (!photo) return bad(res, 'Photo must be a JPG, PNG, WEBP or GIF under 1 MB.');
  }

  const u = req.user;
  const manager = u.role === 'management';
  const report = await Report.create({
    type: b.type, category: b.category, name, description, location, date,
    hasPhoto: !!photo, photo,
    status: manager ? 'verified' : 'pending',          // management posts are trusted
    reporter: { user: u._id, name: u.name, idNo: u.idNo, email: u.email, department: u.department, role: u.role },
    review: manager ? { by: { name: u.name, email: u.email }, at: new Date(), note: 'Posted by management' } : undefined
  });

  await log('REPORT_CREATED', report, u, { category: report.category, location: report.location, date: report.date });
  res.status(201).json(shape.mineReport(report.toObject()));
});

// Photo bytes. Pending/rejected photos are visible only to the owner and management.
router.get('/:id/photo', async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return res.sendStatus(404);
  const r = await Report.findById(req.params.id).select('+photo.data');
  if (!r || !r.hasPhoto || !r.photo || !r.photo.data) return res.sendStatus(404);

  const allowed = req.user.role === 'management'
    || String(r.reporter.user) === String(req.user._id)
    || ['verified', 'returned'].includes(r.status);
  if (!allowed) return res.sendStatus(404);

  res.set('Content-Type', r.photo.contentType);
  res.set('Cache-Control', 'private, max-age=3600');
  res.end(Buffer.from(r.photo.data));
});

module.exports = router;
