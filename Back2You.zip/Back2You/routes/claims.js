const router = require('express').Router();
const mongoose = require('mongoose');
const Report = require('../models/Report');
const Claim = require('../models/Claim');
const { requireAuth } = require('../middleware/auth');
const { clean } = require('../utils/validate');
const { log } = require('../utils/history');

router.use(requireAuth);

// A student/faculty claim goes to MANAGEMENT only — never to the person who posted the report.
router.post('/', async (req, res) => {
  const u = req.user;
  if (u.role === 'management') return res.status(403).json({ message: 'Management handles claims from the console.' });

  const { reportId } = req.body || {};
  const note = clean(req.body && req.body.note, 200);
  if (!mongoose.isValidObjectId(reportId)) return res.status(404).json({ message: 'Item not found.' });
  if (note.length < 8) return res.status(400).json({ message: 'Please add a little more detail (8+ characters).' });

  const report = await Report.findById(reportId);
  if (!report || report.status !== 'verified') return res.status(404).json({ message: 'This item is not open for claims.' });
  if (String(report.reporter.user) === String(u._id)) return res.status(400).json({ message: 'This is your own report.' });

  let claim;
  try {
    claim = await Claim.create({
      report: report._id, itemName: report.name, itemType: report.type,
      by: { user: u._id, name: u.name, idNo: u.idNo, email: u.email, department: u.department, role: u.role },
      note
    });
  } catch (e) {
    if (e.code === 11000) return res.status(409).json({ message: 'You have already sent a request for this item.' });
    throw e;
  }
  await log('CLAIM_SENT', report, u, { claimId: String(claim._id), note });
  res.status(201).json({ id: String(claim._id), status: claim.status, createdAt: claim.createdAt });
});

module.exports = router;
