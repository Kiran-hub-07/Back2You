const router = require('express').Router();
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const User = require('../models/User');
const { startSession, endSession, requireAuth } = require('../middleware/auth');
const { clean, domain, isCampusEmail, ID_PATTERNS } = require('../utils/validate');
const { publicUser } = require('../utils/shape');

const DUMMY_HASH = bcrypt.hashSync('not-a-real-code', 10);   // keeps timing the same for unknown emails
const bad = (res, message, status = 400) => res.status(status).json({ message });

// campus Wi-Fi shares IPs, so the member limit is generous; management is strict
const memberLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: true, legacyHeaders: false,
  message: { message: 'Too many sign-in attempts. Try again later.' } });
const mgmtLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: true, legacyHeaders: false,
  message: { message: 'Too many attempts. Try again in 15 minutes.' } });

// Student / faculty sign-in
router.post('/login', memberLimiter, async (req, res) => {
  const b = req.body || {};
  const role = b.role;
  if (!['student', 'faculty'].includes(role)) return bad(res, 'Choose Student or Faculty.');

  const name = clean(b.name, 70);
  const department = clean(b.department, 40);
  const email = clean(b.email, 100).toLowerCase();
  const idNo = clean(b.idNo, 14).toUpperCase();

  if (!name || !department) return bad(res, 'Please enter your name and department.');
  if (!isCampusEmail(email)) return bad(res, `Please use your official SRET email (@${domain()}).`);
  if (!ID_PATTERNS[role].test(idNo)) {
    return bad(res, role === 'student' ? 'Enter a valid register number (8–14 letters/numbers).'
                                       : 'Enter a valid employee ID (3–14 letters/numbers).');
  }

  let user = await User.findOne({ role, idNo });
  if (user && user.email !== email) {
    return bad(res, 'This ID is already linked to a different email. Contact the college office.', 403);
  }
  try {
    if (!user) user = await User.create({ name, email, idNo, department, role });
    else { user.name = name; user.department = department; await user.save(); }
  } catch (e) {
    if (e.code === 11000) return bad(res, 'Please try again.', 409);
    throw e;
  }
  startSession(res, user);
  res.json({ user: publicUser(user) });
});

// Management sign-in (accounts are created with `npm run create-admin`)
router.post('/login/management', mgmtLimiter, async (req, res) => {
  const email = clean(req.body && req.body.email, 100).toLowerCase();
  const code = String((req.body && req.body.accessCode) || '');
  const user = await User.findOne({ role: 'management', email }).select('+accessCodeHash');
  const ok = await bcrypt.compare(code, user ? user.accessCodeHash : DUMMY_HASH);
  if (!user || !ok) return bad(res, 'Management email or access code is incorrect.', 401);
  startSession(res, user);
  res.json({ user: publicUser(user) });
});

router.get('/me', requireAuth, (req, res) => res.json({ user: publicUser(req.user) }));

router.post('/logout', (req, res) => { endSession(res); res.json({ ok: true }); });

module.exports = router;
