// MANAGEMENT-ONLY API. Everything here is behind requireManagement.
const router = require('express').Router();
const mongoose = require('mongoose');
const Report = require('../models/Report');
const Claim = require('../models/Claim');
const User = require('../models/User');
const History = require('../models/History');
const { requireAuth, requireManagement } = require('../middleware/auth');
const { clean, RECEIVER_ID, escapeRegex } = require('../utils/validate');
const shape = require('../utils/shape');
const { log } = require('../utils/history');
const { toCsv } = require('../utils/csv');

router.use(requireAuth, requireManagement);
router.param('id', (req, res, next, id) =>
  mongoose.isValidObjectId(id) ? next() : res.status(404).json({ message: 'Not found.' }));

const reviewStamp = (u, note) => ({ by: { name: u.name, email: u.email }, at: new Date(), note });

// ---------- dashboard numbers ----------
router.get('/stats', async (req, res) => {
  const [pendingReports, pendingClaims, verified, returned, rejected] = await Promise.all([
    Report.countDocuments({ status: 'pending' }),
    Claim.countDocuments({ status: 'pending' }),
    Report.countDocuments({ status: 'verified' }),
    Report.countDocuments({ status: 'returned' }),
    Report.countDocuments({ status: 'rejected' })
  ]);
  res.json({ pendingReports, pendingClaims, verified, returned, rejected });
});

// ---------- every report, with private reporter details ----------
router.get('/reports', async (req, res) => {
  const { status, q } = req.query;
  const filter = {};
  if (Report.STATUSES.includes(status)) filter.status = status;
  if (q) {
    const rx = new RegExp(escapeRegex(String(q).slice(0, 60)), 'i');
    filter.$or = [{ name: rx }, { description: rx }, { location: rx }, { 'reporter.name': rx }, { 'reporter.idNo': rx }];
  }
  const rows = await Report.find(filter).sort(status === 'pending' ? { createdAt: 1 } : { createdAt: -1 }).limit(200).lean();
  const counts = await Claim.aggregate([
    { $match: { status: 'pending', report: { $in: rows.map(r => r._id) } } },
    { $group: { _id: '$report', n: { $sum: 1 } } }
  ]);
  const map = new Map(counts.map(c => [String(c._id), c.n]));
  res.json(rows.map(r => ({ ...shape.adminReport(r), pendingClaims: map.get(String(r._id)) || 0 })));
});

router.get('/reports/:id', async (req, res) => {
  const r = await Report.findById(req.params.id).lean();
  if (!r) return res.status(404).json({ message: 'Report not found.' });
  const claims = await Claim.find({ report: r._id }).sort({ createdAt: -1 }).lean();
  res.json({ ...shape.adminReport(r), claims: claims.map(shape.adminClaim) });
});

// ---------- verification ----------
router.patch('/reports/:id/verify', async (req, res) => {
  const note = clean(req.body && req.body.note, 200);
  const r = await Report.findOneAndUpdate(
    { _id: req.params.id, status: 'pending' },
    { $set: { status: 'verified', review: reviewStamp(req.user, note) } }, { new: true });
  if (!r) return res.status(409).json({ message: 'This report is not waiting for verification.' });
  await log('REPORT_VERIFIED', r, req.user, { note });
  res.json({ ok: true });
});

router.patch('/reports/:id/reject', async (req, res) => {
  const note = clean(req.body && req.body.note, 200);
  if (note.length < 3) return res.status(400).json({ message: 'Please give a short reason.' });
  const r = await Report.findOneAndUpdate(
    { _id: req.params.id, status: 'pending' },
    { $set: { status: 'rejected', review: reviewStamp(req.user, note) } }, { new: true });
  if (!r) return res.status(409).json({ message: 'This report is not waiting for verification.' });
  await log('REPORT_REJECTED', r, req.user, { note });
  res.json({ ok: true });
});

// ---------- claims ----------
router.get('/claims', async (req, res) => {
  const filter = ['pending', 'approved', 'closed', 'rejected'].includes(req.query.status) ? { status: req.query.status } : {};
  const rows = await Claim.find(filter).sort({ createdAt: 1 }).limit(200).lean();
  res.json(rows.map(shape.adminClaim));
});

router.patch('/claims/:id/reject', async (req, res) => {
  const note = clean(req.body && req.body.note, 200);
  if (note.length < 3) return res.status(400).json({ message: 'Please give a short reason.' });
  const c = await Claim.findOneAndUpdate({ _id: req.params.id, status: 'pending' }, { $set: { status: 'rejected' } }, { new: true });
  if (!c) return res.status(409).json({ message: 'This claim is no longer pending.' });
  await log('CLAIM_REJECTED', { _id: c.report, name: c.itemName, type: c.itemType }, req.user, { note, claimant: c.by.name }, c.by.user);
  res.json({ ok: true });
});

// ---------- handover ----------
router.post('/reports/:id/handover', async (req, res) => {
  const receiverName = clean(req.body && req.body.receiverName, 70);
  const receiverIdNo = clean(req.body && req.body.receiverIdNo, 14).toUpperCase();
  const note = clean(req.body && req.body.note, 200);
  if (!receiverName || !RECEIVER_ID.test(receiverIdNo)) {
    return res.status(400).json({ message: "Enter the receiver's name and a valid ID (3–14 letters/numbers)." });
  }
  const r = await Report.findOneAndUpdate(
    { _id: req.params.id, status: 'verified' },
    { $set: { status: 'returned', handover: { receiverName, receiverIdNo, note, by: { name: req.user.name, email: req.user.email }, at: new Date() } } },
    { new: true });
  if (!r) return res.status(409).json({ message: 'Only verified items that are not yet handed over can be handed over.' });

  // matching claim → approved, every other pending claim on this item → closed
  await Claim.updateMany({ report: r._id, status: 'pending', 'by.idNo': receiverIdNo }, { $set: { status: 'approved' } });
  await Claim.updateMany({ report: r._id, status: 'pending' }, { $set: { status: 'closed' } });

  const target = await User.findOne({ idNo: receiverIdNo, role: { $ne: 'management' } }).select('_id');
  await log('ITEM_HANDED_OVER', r, req.user, { receiverName, receiverIdNo, note }, target && target._id);
  res.json({ ok: true });
});

router.post('/reports/:id/undo-handover', async (req, res) => {
  const old = await Report.findOneAndUpdate(
    { _id: req.params.id, status: 'returned' },
    { $set: { status: 'verified' }, $unset: { handover: '' } }, { new: false });
  if (!old) return res.status(409).json({ message: 'This item is not marked as handed over.' });
  await Claim.updateMany({ report: old._id, status: { $in: ['approved', 'closed'] } }, { $set: { status: 'pending' } });
  const h = old.handover || {};
  await log('HANDOVER_REVERSED', old, req.user, { receiverName: h.receiverName, receiverIdNo: h.receiverIdNo });
  res.json({ ok: true });
});

// ---------- weekly / monthly reports ----------
// period = week (Mon–Sun) | month (calendar month); offset = 0 is the current one, 1 the previous, ...
const dayKey = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const fmtDay = (d, withYear) => d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', ...(withYear ? { year: 'numeric' } : {}) });

function periodRange(query) {
  const period = query.period === 'month' ? 'month' : 'week';
  const offset = Math.min(Math.max(parseInt(query.offset, 10) || 0, 0), 120);
  const now = new Date();
  let from, to, label;
  if (period === 'month') {
    from = new Date(now.getFullYear(), now.getMonth() - offset, 1);
    to = new Date(from.getFullYear(), from.getMonth() + 1, 1);
    label = from.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
  } else {
    const sinceMonday = (now.getDay() + 6) % 7;
    from = new Date(now.getFullYear(), now.getMonth(), now.getDate() - sinceMonday - 7 * offset);
    to = new Date(from.getFullYear(), from.getMonth(), from.getDate() + 7);
    label = `${fmtDay(from)} – ${fmtDay(new Date(to.getTime() - 1), true)}`;
  }
  return { period, offset, from, to, label };
}

const topN = (items, n) => {
  const m = new Map();
  items.forEach(v => m.set(v, (m.get(v) || 0) + 1));
  return [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, n);
};

router.get('/summary', async (req, res) => {
  const { period, offset, from, to, label } = periodRange(req.query);
  const inRange = { $gte: from, $lt: to };

  const [reports, returnedRows, approved, rejected, claimsReceived] = await Promise.all([
    Report.find({ createdAt: inRange }).sort({ createdAt: -1 }).limit(2000).lean(),
    Report.find({ 'handover.at': inRange, status: 'returned' }).select('handover.at').lean(),
    Report.countDocuments({ 'review.at': inRange, status: { $in: ['verified', 'returned'] } }),
    Report.countDocuments({ 'review.at': inRange, status: 'rejected' }),
    Claim.countDocuments({ createdAt: inRange })
  ]);

  const lost = reports.filter(r => r.type === 'Lost').length;
  const found = reports.length - lost;
  const foundUncollected = reports.filter(r => r.type === 'Found' && ['verified', 'pending'].includes(r.status)).length;

  // one bucket per day
  const buckets = new Map();
  for (let d = new Date(from); d < to; d = new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1)) {
    buckets.set(dayKey(d), { date: dayKey(d), reported: 0, returned: 0 });
  }
  reports.forEach(r => { const b = buckets.get(dayKey(new Date(r.createdAt))); if (b) b.reported++; });
  returnedRows.forEach(r => { const b = r.handover && buckets.get(dayKey(new Date(r.handover.at))); if (b) b.returned++; });

  res.json({
    period, offset, label, from: dayKey(from), to: dayKey(new Date(to.getTime() - 1)),
    totals: { reported: reports.length, lost, found, approved, rejected, returned: returnedRows.length, claimsReceived, foundUncollected },
    daily: [...buckets.values()],
    byCategory: topN(reports.map(r => r.category), 7).map(([name, count]) => ({ name, count })),
    topLocations: topN(reports.map(r => r.location.trim()), 5).map(([name, count]) => ({ name, count })),
    reports: reports.map(shape.adminReport)
  });
});

router.get('/summary/export', async (req, res) => {
  const { period, from, to } = periodRange(req.query);
  const rows = await Report.find({ createdAt: { $gte: from, $lt: to } }).sort({ createdAt: 1 }).limit(5000).lean();
  const out = rows.map(r => ({
    Item: r.name, Type: r.type, Category: r.category, Location: r.location, 'Date lost/found': r.date,
    Status: r.status, 'Reported on': r.createdAt,
    'Reported by': r.reporter && r.reporter.name, 'Reporter ID': r.reporter && r.reporter.idNo,
    Department: r.reporter && r.reporter.department,
    'Handed over to': r.handover && r.handover.receiverName, 'Handed over on': r.handover && r.handover.at
  }));
  res.set('Content-Type', 'text/csv; charset=utf-8');
  res.set('Content-Disposition', `attachment; filename="back2you-${period}ly-report-${dayKey(from)}.csv"`);
  res.send(toCsv(out));
});

// ---------- found items nobody has collected yet ----------
router.get('/uncollected', async (req, res) => {
  const rows = await Report.find({ type: 'Found', status: { $in: ['verified', 'pending'] } })
    .sort({ date: 1, createdAt: 1 }).limit(500).lean();
  const counts = await Claim.aggregate([
    { $match: { status: 'pending', report: { $in: rows.map(r => r._id) } } },
    { $group: { _id: '$report', n: { $sum: 1 } } }
  ]);
  const map = new Map(counts.map(c => [String(c._id), c.n]));
  res.json(rows.map(r => ({ ...shape.adminReport(r), pendingClaims: map.get(String(r._id)) || 0 })));
});

// ---------- export (CSV / JSON) ----------
const EXPORTS = {
  reports: { model: Report, sort: { createdAt: -1 } },
  claims: { model: Claim, sort: { createdAt: -1 } },
  history: { model: History, sort: { timestamp: -1 } }
};

router.get('/export/:what', async (req, res) => {
  const what = req.params.what;
  if (!Object.hasOwn(EXPORTS, what)) return res.status(404).json({ message: 'Unknown export.' });
  const rows = await EXPORTS[what].model.find().sort(EXPORTS[what].sort).limit(20000).lean();
  const json = req.query.format === 'json';
  const file = `back2you-${what}-${new Date().toISOString().slice(0, 10)}.${json ? 'json' : 'csv'}`;
  res.set('Content-Type', json ? 'application/json' : 'text/csv; charset=utf-8');
  res.set('Content-Disposition', `attachment; filename="${file}"`);
  res.send(json ? JSON.stringify(rows, null, 2) : toCsv(rows));
});

module.exports = router;
