const { Schema, model } = require('mongoose');

const userSchema = new Schema({
  name: { type: String, required: true, trim: true, maxlength: 70 },
  email: { type: String, required: true, lowercase: true, trim: true },
  idNo: { type: String, uppercase: true, trim: true, default: '' },   // register no. (student) / employee ID (faculty)
  department: { type: String, trim: true, default: '' },
  role: { type: String, enum: ['student', 'faculty', 'management'], required: true },
  accessCodeHash: { type: String, select: false }                      // management only (bcrypt)
}, { timestamps: true });

userSchema.index({ role: 1, idNo: 1 }, { unique: true, partialFilterExpression: { idNo: { $gt: '' } } });
userSchema.index({ role: 1, email: 1 });

module.exports = model('User', userSchema);
