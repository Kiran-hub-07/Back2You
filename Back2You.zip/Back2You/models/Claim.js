const { Schema, model } = require('mongoose');

const claimSchema = new Schema({
  report: { type: Schema.Types.ObjectId, ref: 'Report', required: true, index: true },
  itemName: String,
  itemType: String,
  by: {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    name: String, idNo: String, email: String, department: String, role: String
  },
  note: { type: String, required: true, maxlength: 200 },
  status: { type: String, enum: ['pending', 'approved', 'closed', 'rejected'], default: 'pending', index: true }
}, { timestamps: true });

claimSchema.index({ report: 1, 'by.user': 1 }, { unique: true });   // one claim per person per item

module.exports = model('Claim', claimSchema);
