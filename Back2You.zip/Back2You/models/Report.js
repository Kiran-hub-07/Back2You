const { Schema, model } = require('mongoose');

const CATEGORIES = ['Electronics', 'ID & Cards', 'Bags', 'Books & Notes', 'Accessories', 'Clothing', 'Other'];
const STATUSES = ['pending', 'verified', 'rejected', 'returned'];

const reportSchema = new Schema({
  type: { type: String, enum: ['Lost', 'Found'], required: true },
  category: { type: String, enum: CATEGORIES, required: true },
  name: { type: String, required: true, trim: true, maxlength: 70 },
  description: { type: String, required: true, trim: true, maxlength: 350 },
  location: { type: String, required: true, trim: true, maxlength: 100 },
  date: { type: String, required: true },                 // YYYY-MM-DD
  hasPhoto: { type: Boolean, default: false },
  photo: {
    data: { type: Buffer, select: false },                // never loaded unless asked for
    contentType: String
  },

  // pending → (management) → verified | rejected ; verified → returned (handover)
  status: { type: String, enum: STATUSES, default: 'pending', index: true },

  // PRIVATE: only management ever receives these fields
  reporter: {
    user: { type: Schema.Types.ObjectId, ref: 'User', index: true },
    name: String, idNo: String, email: String, department: String, role: String
  },
  review: { by: { name: String, email: String }, at: Date, note: String },
  handover: {
    receiverName: String, receiverIdNo: String, note: String,
    by: { name: String, email: String }, at: Date
  }
}, { timestamps: true });

reportSchema.index({ createdAt: -1 });

module.exports = model('Report', reportSchema);
module.exports.CATEGORIES = CATEGORIES;
module.exports.STATUSES = STATUSES;
