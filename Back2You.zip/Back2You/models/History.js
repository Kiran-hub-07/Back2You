const { Schema, model } = require('mongoose');

const ACTIONS = [
  'REPORT_CREATED', 'REPORT_VERIFIED', 'REPORT_REJECTED',
  'CLAIM_SENT', 'CLAIM_REJECTED', 'ITEM_HANDED_OVER', 'HANDOVER_REVERSED'
];

const historySchema = new Schema({
  action: { type: String, enum: ACTIONS, required: true },
  report: { type: Schema.Types.ObjectId, ref: 'Report' },
  itemName: String,
  itemType: String,
  ownerId: { type: Schema.Types.ObjectId, index: true },      // who posted the report
  targetUser: { type: Schema.Types.ObjectId, index: true },   // claimant / receiver
  actor: { user: { type: Schema.Types.ObjectId, index: true }, name: String, idNo: String, email: String, department: String, role: String },
  details: { type: Schema.Types.Mixed, default: {} }
}, { timestamps: { createdAt: 'timestamp', updatedAt: false } });

historySchema.index({ timestamp: -1 });

module.exports = model('History', historySchema);
module.exports.ACTIONS = ACTIONS;
