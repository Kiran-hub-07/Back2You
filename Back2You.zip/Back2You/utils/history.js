const History = require('../models/History');

// report: any object with _id, name, type and optionally reporter.user
exports.log = (action, report, actor, details = {}, targetUser) =>
  History.create({
    action,
    report: report && report._id,
    itemName: report ? report.name : '',
    itemType: report ? report.type : '',
    ownerId: report && report.reporter ? report.reporter.user : undefined,
    targetUser,
    actor: { user: actor._id, name: actor.name, idNo: actor.idNo, email: actor.email, department: actor.department, role: actor.role },
    details
  });
