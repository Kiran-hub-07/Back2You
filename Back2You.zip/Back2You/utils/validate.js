const clean = (v, max = 200) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, max);

const domain = () => (process.env.CAMPUS_DOMAIN || 'sret.edu.in').toLowerCase();
const isCampusEmail = e => /^[^\s@]{3,}@[^\s@]+$/.test(e) && e.endsWith('@' + domain());

const ID_PATTERNS = { student: /^[A-Z0-9]{8,14}$/, faculty: /^[A-Z0-9]{3,14}$/ };
const RECEIVER_ID = /^[A-Z0-9]{3,14}$/;

const isValidDate = s => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(s + 'T12:00:00Z');
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
};
const notInFuture = s => s <= new Date(Date.now() + 36 * 3600e3).toISOString().slice(0, 10);
const escapeRegex = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

module.exports = { clean, domain, isCampusEmail, ID_PATTERNS, RECEIVER_ID, isValidDate, notInFuture, escapeRegex };
