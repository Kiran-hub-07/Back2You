// Accepts a data URL from the browser and returns { data: Buffer, contentType } or null.
const MAX_BYTES = 1024 * 1024;

function sniff(buf) {
  if (buf.length < 12) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (buf[0] === 0x89 && buf.toString('ascii', 1, 4) === 'PNG') return 'image/png';
  if (buf.toString('ascii', 0, 4) === 'GIF8') return 'image/gif';
  if (buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') return 'image/webp';
  return null;
}

module.exports = function parsePhoto(dataUrl) {
  const m = /^data:image\/(?:jpeg|png|webp|gif);base64,([A-Za-z0-9+/=]+)$/.exec(String(dataUrl || ''));
  if (!m) return null;
  const data = Buffer.from(m[1], 'base64');
  if (!data.length || data.length > MAX_BYTES) return null;
  const contentType = sniff(data);          // trust the real bytes, not the label
  return contentType ? { data, contentType } : null;
};
