// Decides exactly which fields leave the server. Reporter details are ONLY in adminReport.
const ROLE_LABEL = { student: 'Student', faculty: 'Faculty', management: 'Management office' };

const base = r => ({
  id: String(r._id), type: r.type, category: r.category, name: r.name,
  description: r.description, location: r.location, date: r.date,
  hasPhoto: !!r.hasPhoto, status: r.status, createdAt: r.createdAt
});

exports.publicReport = (r, me, claimMap) => ({
  ...base(r),
  postedBy: ROLE_LABEL[r.reporter && r.reporter.role] || 'Campus member',
  mine: String(r.reporter && r.reporter.user) === String(me._id),
  myClaim: claimMap.get(String(r._id)) || null
});

exports.mineReport = r => ({
  ...base(r),
  mine: true,
  reviewNote: (r.review && r.review.note) || ''
});

exports.adminReport = r => ({
  ...base(r),
  reporter: {
    name: r.reporter.name, idNo: r.reporter.idNo, email: r.reporter.email,
    department: r.reporter.department, role: r.reporter.role
  },
  review: r.review || null,
  handover: r.handover && r.handover.at ? r.handover : null
});

exports.adminClaim = c => ({
  id: String(c._id), reportId: String(c.report), itemName: c.itemName, itemType: c.itemType,
  by: { name: c.by.name, idNo: c.by.idNo, email: c.by.email, department: c.by.department, role: c.by.role },
  note: c.note, status: c.status, createdAt: c.createdAt
});

exports.publicUser = u => ({
  id: String(u._id), name: u.name, email: u.email, idNo: u.idNo, department: u.department, role: u.role
});
