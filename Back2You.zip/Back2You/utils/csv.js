// Flattens nested Mongo docs ({a:{b:1}} → {"a.b":1}) and writes safe CSV.
function flatten(obj, prefix = '', out = {}) {
  for (const [k, v] of Object.entries(obj || {})) {
    if (k === '__v') continue;
    const key = prefix ? `${prefix}.${k}` : k;
    if (v instanceof Date) out[key] = v.toISOString();
    else if (v && v._bsontype) out[key] = String(v);
    else if (Array.isArray(v)) out[key] = JSON.stringify(v);
    else if (v && typeof v === 'object') flatten(v, key, out);
    else out[key] = v;
  }
  return out;
}

function cell(v) {
  let s = String(v ?? '');
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;          // stop spreadsheet formula injection
  return `"${s.replace(/"/g, '""')}"`;
}

function toCsv(rows) {
  const flat = rows.map(r => flatten(r));
  const cols = [...new Set(flat.flatMap(r => Object.keys(r)))];
  return [cols.map(cell).join(','), ...flat.map(r => cols.map(c => cell(r[c])).join(','))].join('\r\n');
}

module.exports = { flatten, toCsv };
