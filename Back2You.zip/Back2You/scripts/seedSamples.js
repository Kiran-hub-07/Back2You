// Optional: loads the six demo items from the old prototype as already-verified reports.
//   npm run seed
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const Report = require('../models/Report');
const User = require('../models/User');

const day = n => new Date(Date.now() - n * 864e5).toISOString().slice(0, 10);
const samples = [
  ['Found', 'Electronics', 'Wireless earbuds case', 'A white earbuds charging case found near the central library entrance.', 'Central Library', 1],
  ['Lost', 'ID & Cards', 'Student ID card', 'A student ID card in a clear holder. Please check the name before handing it over.', 'University cafeteria', 2],
  ['Found', 'Bags', 'Navy blue backpack', 'A navy backpack left beside the study tables. Describe a distinguishing detail to identify it.', 'Reading room', 2],
  ['Lost', 'Electronics', 'Black USB drive', 'Small black USB drive, possibly left after a lab session.', 'Computer lab', 3],
  ['Found', 'Books & Notes', 'Engineering notebook', 'A ruled notebook with handwritten class notes found on a bench.', 'Academic block', 3],
  ['Lost', 'Accessories', 'Silver keychain', 'A small silver keychain with two keys.', 'Main walkway', 4]
];

(async () => {
  await connectDB();
  const office = await User.findOne({ role: 'management' });
  if (!office) { console.error('Create a management account first (npm run create-admin).'); process.exit(1); }
  for (const [type, category, name, description, location, ago] of samples) {
    if (await Report.exists({ name, location })) continue;
    await Report.create({
      type, category, name, description, location, date: day(ago), status: 'verified',
      reporter: { user: office._id, name: office.name, idNo: '', email: office.email, department: 'Management', role: 'management' },
      review: { by: { name: office.name, email: office.email }, at: new Date(), note: 'Sample data' }
    });
  }
  console.log('Sample items loaded.');
  await mongoose.disconnect();
})();
