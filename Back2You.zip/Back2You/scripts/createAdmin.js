// Usage:  npm run create-admin -- "Full Name" "name@sret.edu.in" "a-long-access-code"
// Creates (or updates the code of) a management account. The code is stored hashed.
require('dotenv').config();
const bcrypt = require('bcryptjs');
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const User = require('../models/User');
const { isCampusEmail, domain, clean } = require('../utils/validate');

(async () => {
  const [name, emailRaw, code] = process.argv.slice(2);
  const email = clean(emailRaw, 100).toLowerCase();
  if (!name || !email || !code) {
    console.error('Usage: npm run create-admin -- "Full Name" "name@' + domain() + '" "access-code"');
    process.exit(1);
  }
  if (!isCampusEmail(email)) { console.error(`Email must end with @${domain()}`); process.exit(1); }
  if (code.length < 10) { console.error('Use an access code of at least 10 characters.'); process.exit(1); }

  await connectDB();
  const accessCodeHash = await bcrypt.hash(code, 12);
  await User.findOneAndUpdate(
    { role: 'management', email },
    { $set: { name: clean(name, 70), accessCodeHash, department: 'Management' }, $setOnInsert: { idNo: '' } },
    { upsert: true, new: true, setDefaultsOnInsert: true });
  console.log(`Management account ready: ${email}`);
  await mongoose.disconnect();
})();
