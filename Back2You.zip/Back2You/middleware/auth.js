const jwt = require('jsonwebtoken');
const User = require('../models/User');

const COOKIE = 'b2y_token';
const cookieOpts = () => ({ httpOnly: true, sameSite: 'strict', secure: process.env.NODE_ENV === 'production' });

exports.startSession = (res, user) => {
  const token = jwt.sign({ id: String(user._id) }, process.env.JWT_SECRET, { expiresIn: '8h' });
  res.cookie(COOKIE, token, { ...cookieOpts(), maxAge: 8 * 3600 * 1000 });
};
exports.endSession = res => res.clearCookie(COOKIE, cookieOpts());

// Role always comes from the database, never from the token or the browser.
exports.requireAuth = async (req, res, next) => {
  try {
    const token = req.cookies && req.cookies[COOKIE];
    if (!token) throw new Error('no token');
    const { id } = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(id);
    if (!user) throw new Error('no user');
    req.user = user;
    next();
  } catch {
    res.status(401).json({ message: 'Please sign in again.' });
  }
};

exports.requireManagement = (req, res, next) =>
  req.user.role === 'management' ? next() : res.status(403).json({ message: 'Management access only.' });
